## Build Riak with RiakJson
cd riak
make rel

## Start Riak
ulimit -n 4096 ; ./rel/riak/bin/riak start

## Build Riak Json (for testing)
cd ../riak_json
make

## Unit test only
make test

## Unit test and Integration test (uses localhost:8098)
make itest
